import Foundation

// Define the size of the game board
let boardSize = 7

// Define the symbols for different items on the board
let emptySymbol = "◻️"
let playerSymbol = "🧑"
let itemSymbols = ["💎", "💰", "🔑", "📦"]

// Define the types of items
enum ItemType: String {
    case diamond = "💎"
    case money = "💰"
    case key = "🔑"
    case crate = "📦"
}

// Define the game board as a 2D array
var gameBoard = [[String]](repeating: [String](repeating: emptySymbol, count: boardSize), count: boardSize)

// Function to randomly place items on the board
func placeItems() {
    for _ in 1...(boardSize * boardSize / 2) {
        let row = Int.random(in: 0..<boardSize)
        let col = Int.random(in: 0..<boardSize)
        let itemIndex = Int.random(in: 0..<itemSymbols.count)
        gameBoard[row][col] = itemSymbols[itemIndex]
    }
}

// Function to print the game board
func printBoard() {
    for row in gameBoard {
        print(row.joined(separator: " "))
    }
}

// Define a struct to represent a player
struct Player {
    var name: String
    var position: (row: Int, col: Int)
    var inventory: [ItemType: Int] // Using a dictionary to store items and their quantities
}

// Function to move the player on the game board
func movePlayer(player: inout Player, direction: String) {
    var (row, col) = player.position
    switch direction {
    case "up":
        row = max(row - 1, 0)
    case "down":
        row = min(row + 1, boardSize - 1)
    case "left":
        col = max(col - 1, 0)
    case "right":
        col = min(col + 1, boardSize - 1)
    default:
        break
    }
    player.position = (row, col)
}

// Function to simulate player collecting items
func collectItem(player: inout Player) {
    let (row, col) = player.position
    let itemString = gameBoard[row][col]
    if let itemType = ItemType(rawValue: itemString) {
        if let count = player.inventory[itemType] {
            player.inventory[itemType] = count + 1
        } else {
            player.inventory[itemType] = 1
        }
        gameBoard[row][col] = emptySymbol
    }
}

// Initialize players
var player1 = Player(name: "Player 1", position: (0, 0), inventory: [:])
var player2 = Player(name: "Player 2", position: (boardSize - 1, boardSize - 1), inventory: [:])

// Function to display player's inventory
func displayInventory(player: Player) {
    print("\(player.name)'s Inventory:")
    for (item, count) in player.inventory {
        print("\(item.rawValue): \(count)")
    }
}

// Simulate the game
placeItems()
print("Initial Board:")
printBoard()

// Player 1 moves around the board
movePlayer(player: &player1, direction: "right")
movePlayer(player: &player1, direction: "down")
collectItem(player: &player1)

// Player 2 moves around the board
movePlayer(player: &player2, direction: "up")
movePlayer(player: &player2, direction: "left")
collectItem(player: &player2)

// Player 1 moves around and collects more items
movePlayer(player: &player1, direction: "right")
collectItem(player: &player1)

// Player 2 moves around and collects more items
movePlayer(player: &player2, direction: "down")
collectItem(player: &player2)

// Player 1 moves around and collects more items
movePlayer(player: &player1, direction: "down")
collectItem(player: &player1)

// Print final board and player inventories
print("\nFinal Board:")
printBoard()
displayInventory(player: player1)
displayInventory(player: player2)
